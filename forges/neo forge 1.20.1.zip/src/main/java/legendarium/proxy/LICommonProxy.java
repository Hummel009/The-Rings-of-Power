package legendarium.proxy;

public class LICommonProxy {
}